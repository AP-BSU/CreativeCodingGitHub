//
let previewX, previewY;
let paintedCircles = [];

function setup() {
  createCanvas(800, 600);
}

function draw() {
  background(220);

  // Displays hover preview in gray
  if (!mouseIsPressed) {
    fill(200);
    ellipse(previewX, previewY, 20, 20);
  }

  // Paints small circles
  paintedCircles.forEach(circle => {
    fill(circle.color);
    ellipse(circle.x, circle.y, 20, 20);
  });
}
  // Left click to paint
function mousePressed() {
  // Saves the cursor position when mouse is pressed
  previewX = mouseX;
  previewY = mouseY;
}

function mouseReleased() {
  // Paint and apply a circle at the cursor's position when released
  // Circles are randomly colored when painted
  paintedCircles.push({
    x: mouseX,
    y: mouseY,
    color: color(random(255), random(255), random(255))
  });
}