// Whole Data Pie Chart
let data = [49.4, 50.4]; // Data of percentages between the genders of male and females in Earth (7.95 Billion people)
let colors = ["pink", "blue"]; // Chart colorings
let labels = ["Data 1", "Data 2"]; // Variables/Groupings
let title = "Percentage of Males and Females in Earth"; // Top text (title)
let canvasSize = 600; // Canvas

function setup() { // Center alignment for text
  createCanvas(canvasSize, canvasSize); // Canvas value
  noLoop(); // Canvas Loop
  textAlign(CENTER, CENTER); 
}

function draw() { // background to white
  background(255); 
  drawTitle(title);
  drawPieChart(data, colors);
}

function drawPieChart(data, colors) {
  let total = data.reduce((acc, val) => acc + val, 0);
  let diameter = min(width, height) * 0.8; // Set pie-chart diameter to fit within canvas

  let angleStart = -HALF_PI; // Start at the top

  for (let i = 0; i < data.length; i++) {
    let angleEnd = angleStart + (data[i] / total) * TWO_PI;
    fill(colors[i]);
    arc(width / 2, height / 2, diameter, diameter, angleStart, angleEnd, PIE);

// To calculate the angles (Extension)
    let angleMiddle = angleStart + (angleEnd - angleStart) / 2;
    let x = width / 2 + cos(angleMiddle) * (diameter / 2) * 0.7; // Adjusted position
    let y = height / 2 + sin(angleMiddle) * (diameter / 2) * 0.7; // Adjusted position

    fill(255); // Text color
    text(`${data[i]}%`, x, y);
    angleStart = angleEnd;
  }
}

function drawTitle(title) { // text color
  fill(0);
  textSize(24);
  text(title, width / 2, 30); // Position at the top
}
