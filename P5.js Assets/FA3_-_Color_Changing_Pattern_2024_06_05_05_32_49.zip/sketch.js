let maxCol = 5;
let maxRow = 4;
let circleD = 60;

function setup() {
  createCanvas(400, 400);
  noStroke();
  colorMode(HSB, 360, 100, 100);
  background(0, 0, 0);

  let xSpacing = width / maxCol;
  let ySpacing = height / maxRow;
  translate(30, 20);

  for (let x = 0; x < maxCol; x++) {
    for (let y = 0; y < maxRow; y++) {
      // Randomize red color for circles
      if (random() < 0.5) {
        fill(0, 100, 100); // Red color
      } else {
        fill(0, 0, 100); // White color
      }
      ellipse(x * xSpacing, y * ySpacing, circleD, circleD);
    }
  }
}
