//Begins with blank then slowly distorts based on the image

let img;

function preload() {
  img = loadImage('tree.jpg'); // Load the image
}

function setup() {
  createCanvas(400, 400);
  background(0);
}

function draw() {
  let x = random(width); // Random x coordinate
  let y = random(height); // Random y coordinate
  let c = img.get(x, y); // Get the color from the image at the random coordinate

  // Fill the ellipse with the color and draw it
  fill(c[0], c[1], c[2], 100); // Alpha value reduced to 100 for better blending
  noStroke();
  ellipse(x, y, 30, 30); // Draw ellipse at random position
}
