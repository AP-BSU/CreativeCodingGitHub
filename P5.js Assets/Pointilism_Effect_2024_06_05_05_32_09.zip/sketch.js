// Note images are deleted but can be uploaded for loading
let doveImg;
let triangleVertices = [];

function preload() {
  doveImg = loadImage("dove03.png");
}

function setup() {
  createCanvas(480, 400);
  doveImg.resize(120, 100);

  // Define the vertices of the yellow triangle
  triangleVertices.push(createVector(200, 50));
  triangleVertices.push(createVector(50, 350));
  triangleVertices.push(createVector(350, 350));
}

function draw() {
  background(220);

  // Draw the yellow triangle
  fill(255, 204, 0);
  beginShape();
  for (let i = 0; i < triangleVertices.length; i++) {
    vertex(triangleVertices[i].x, triangleVertices[i].y);
  }
  endShape(CLOSE);

  // Pointillism effect within the triangle
  loadPixels();
  for (let i = 0; i < width; i += 5) {
    for (let j = 0; j < height; j += 5) {
      if (isInsideTriangle(i, j)) {
        let c = get(i, j);
        fill(c);
        noStroke();
        ellipse(i, j, 5, 5);
      }
    }
  }

  // Draw the dove image centered in the triangle
  imageMode(CENTER);
  image(doveImg, 200, 250);
}

// Function to check if a point is inside the triangle
function isInsideTriangle(x, y) {
  let p1 = triangleVertices[0];
  let p2 = triangleVertices[1];
  let p3 = triangleVertices[2];

  let d1 = sign(x, y, p1.x, p1.y, p2.x, p2.y);
  let d2 = sign(x, y, p2.x, p2.y, p3.x, p3.y);
  let d3 = sign(x, y, p3.x, p3.y, p1.x, p1.y);

  let hasNeg = (d1 < 0) || (d2 < 0) || (d3 < 0);
  let hasPos = (d1 > 0) || (d2 > 0) || (d3 > 0);

  return !(hasNeg && hasPos);
}

// Function to calculate the sign of the area of a triangle
function sign(x1, y1, x2, y2, x3, y3) {
  return (x1 - x3) * (y2 - y3) - (x2 - x3) * (y1 - y3);
}
