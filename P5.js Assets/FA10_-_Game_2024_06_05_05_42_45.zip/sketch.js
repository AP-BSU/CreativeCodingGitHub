let player; ////Starting of game
let aliens = [];
let bullets = [];
let score = 0;
let highscore = 0;
let alienSpeed = 2;
let playerSpeed = 7;
let gameState = 'playing'; // Can be 'playing' or 'game-over'
let isLeftArrowDown = false;
let isRightArrowDown = false;

function setup() { ////Sketch and background
    createCanvas(600, 400);
    player = new Player();
    spawnAliens();
}

function draw() { ////Start of functions
    background(0);
    displayHighscore(); ////Highscore

    if (gameState === 'playing') {
        player.show();
        player.update();
        
        for (let alien of aliens) {
            alien.show();
            alien.update();
            if (alien.hits(player)) {
                endGame();
            }
        }
        
        for (let i = bullets.length - 1; i >= 0; i--) {
            bullets[i].show();
            bullets[i].update();
            if (bullets[i].hits(aliens)) {
                bullets.splice(i, 1);
                score++;
                if (score > highscore) {
                    highscore = score;
                }
            }
        }
        ////Alien speed and spawn
        if (aliens.length === 0) {
            spawnAliens();
            alienSpeed += 0.5; // Difficulty codes to increase speed on wave completion
          
        } ////Game over screen
    } else if (gameState === 'game-over') {
        textSize(32);
        fill(255);
        textAlign(CENTER, CENTER);
        text('Game Over', width / 2, height / 2 - 50);
        textSize(20);
        text(`Your Score: ${score}`, width / 2, height / 2);
        text(`Highscore: ${highscore}`, width / 2, height / 2 + 30);
        text('Press ENTER to Retry', width / 2, height / 2 + 60);
    }
}
////Controls section
function keyPressed() {
    if (gameState === 'playing') {
        if (keyCode === LEFT_ARROW) {
            isLeftArrowDown = true;
        } else if (keyCode === RIGHT_ARROW) {
            isRightArrowDown = true;
        } else if (key === ' ') {
            bullets.push(new Bullet(player.x + player.size / 2, height - player.size));
        }
    } else if (gameState === 'game-over' && keyCode === ENTER) {
        resetGame();
    }
}

function keyReleased() {
    if (keyCode === LEFT_ARROW) {
        isLeftArrowDown = false;
    } else if (keyCode === RIGHT_ARROW) {
        isRightArrowDown = false;
    }
}
////Highscore text appears on top left
function displayHighscore() {
    textSize(16);
    fill(255);
    text(`Highscore: ${highscore}`, 10, 20);
}
////Retry variable to restart game from last wave and reset current score

function resetGame() {
    score = 0;
    gameState = 'playing';
    player = new Player();
    bullets = [];
    aliens = [];
    spawnAliens();
    alienSpeed = 2;
}
////Spawning of 7 aliens (Green boxes) upon wave completion

function spawnAliens() {
    for (let i = 0; i < 6; i++) {
        aliens.push(new Alien(i * 100 + 50, 50));
    } ////Section of player properties
}
////Game over summery screen
function endGame() {
    gameState = 'game-over';
    if (score > highscore) {
        highscore = score;
    }
}
////Game over trigger upon the player being touched by the alien
class Player {
    constructor() {
        this.size = 50;
        this.x = width / 2 - this.size / 2;
        this.y = height - this.size;
        this.speed = playerSpeed;
    }
////Player placements
    move(dir) {
        this.x += dir * this.speed;
        this.x = constrain(this.x, 0, width - this.size);
    }

    show() {
        fill(255);
        rect(this.x, this.y, this.size, this.size);
    }

    update() {
        if (isLeftArrowDown) {
            this.move(-1);
        } else if (isRightArrowDown) {
            this.move(1);
        }
    }
}

class Alien {
    constructor(x, y) {
        this.size = 30;
        this.x = x;
        this.y = y;
        this.speed = alienSpeed;
    }

    show() {
        fill(0, 255, 0);
        rect(this.x, this.y, this.size, this.size);
    }

    update() {
        this.x += this.speed;
        if (this.x + this.size >= width || this.x <= 0) {
            this.speed *= -1;
            this.y += this.size; // Move down
        }
    }

    hits(player) {
        return (player.x < this.x + this.size &&
                player.x + player.size > this.x &&
                player.y < this.y + this.size &&
                player.y + player.size > this.y);
    }
}
////Projectile variables $ properties
class Bullet {
    constructor(x, y) {
        this.x = x;
        this.y = y;
        this.size = 5;
        this.speed = 5;
    }

    show() {
        fill(255);
        ellipse(this.x, this.y, this.size);
    }

    update() {
        this.y -= this.speed;
    }
////Condition on alien hit and movement
    hits(aliens) {
        for (let alien of aliens) {
            if (this.x > alien.x && this.x < alien.x + alien.size &&
                this.y > alien.y && this.y < alien.y + alien.size) {
                aliens.splice(aliens.indexOf(alien), 1);
                return true;
            }
        }
        return false;
    }
}
