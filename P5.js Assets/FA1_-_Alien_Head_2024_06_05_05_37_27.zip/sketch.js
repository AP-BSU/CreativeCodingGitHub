// Start of sketch & background
function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);

  // Translate the sketch positioning
  translate(width / 24, height / 100);

  // Alien head
  fill(150);
  ellipse(200, 200, 200, 250);

  // White Eyes
  fill(255);
  ellipse(160, 180, 50, 30);
  ellipse(240, 180, 50, 30);

  // Scary Mouth
  stroke(0);
  strokeWeight(2);
  noFill();
  arc(200, 240, 100, 50, 0, PI);

  // Triangular Nose
  fill(150);
  triangle(200, 200, 180, 220, 220, 220);
}
