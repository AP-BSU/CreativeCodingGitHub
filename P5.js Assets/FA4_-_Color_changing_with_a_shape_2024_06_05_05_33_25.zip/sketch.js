//Line color randomizes on each new play sketch run
function setup() {
  createCanvas(400, 400);
  background(220);

  let colors = []; // Array to hold random colors

  // Generate four random colors
  for (let i = 0; i < 4; i++) {
    colors.push(color(random(255), random(255), random(255)));
  }

  // Draw the square
  let size = 200;
  let x = (width - size) / 2;
  let y = (height - size) / 2;
  fill(255);
  rect(x, y, size, size);

  // Draw four lines with random colors inside the square
  for (let i = 0; i < 4; i++) {
    strokeWeight(10); // Make the lines thicker
    stroke(colors[i]);
    line(x, y + i * (size / 4) + size / 8, x + size, y + i * (size / 4) + size / 8);
  }
}
